# 03 Data Overview

# Dimension of the data
df.shape

# Summary of the dataset
df.describe()

# Missing values for every column
df.isna().sum()
